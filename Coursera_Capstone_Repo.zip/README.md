
# Coursera IBM Data Science Capstone Project

## Project Title: Full Data Science Pipeline - Classification Problem

### Objective

To demonstrate end-to-end data science workflow using real-world data including:

- Data Collection & Wrangling
- Exploratory Data Analysis (EDA) with Visualization
- EDA with SQL
- Interactive Mapping with Folium
- Dashboard Development with Plotly Dash
- Predictive Modeling using Classification Algorithms

### Dataset

- dataset_part_1.csv
- dataset_part_2.csv
- dataset_part_3.csv

### Notebooks

- 1_DataCollection_Wrangling.ipynb
- 2_EDA_Visualization.ipynb
- 3_EDA_SQL.ipynb
- 4_Folium_InteractiveMap.ipynb
- 5_Plotly_Dash_Dashboard.ipynb
- 6_Predictive_Analysis_Classification.ipynb

### Tools Used

- Python
- Pandas
- SQL
- Scikit-learn
- Seaborn
- Matplotlib
- Folium
- Plotly Dash

### Summary Results

- Best model: Decision Tree Classifier
- Accuracy: 83.33%
- Fully interactive dashboards and maps created.
- Complete reproducibility of analysis.

### Submission Files

- Capstone_Presentation_Full_Finalized.pdf (uploaded to Coursera)

### Author

Your Name

### License

For peer-review submission only.
